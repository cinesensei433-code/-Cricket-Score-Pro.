CRICKET SCORE PRO — DEMO 0.1

Included:
- Responsive single-file scoring demo for Android Chrome
- Local browser save (localStorage)
- Team/player names, player count and overs limit
- Run buttons, extras, wickets, undo
- Basic batter/bowler views, extras and fall of wickets
- Exportable score summary

How to test on Android:
1. Download and extract the ZIP.
2. Open index.html in a browser if your file manager offers that option.
3. If local-file opening is blocked, upload index.html to a static hosting service (such as GitHub Pages or Netlify) using their mobile website, then open the resulting HTTPS page in Chrome.

Important:
This is a functional prototype, NOT an installable APK yet. It does not include cloud sync, live score link sharing, or a fully verified official cricket scoring engine. Before release, test and fix edge cases (especially strike changes, run-outs, bowler figures, innings swap and dismissal rules), then wrap/build it as an Android APK and test on the target phone.
